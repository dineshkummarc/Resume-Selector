#!C:/Python27/python

print()
import cgi

print("<h1>this is heading</h1>")